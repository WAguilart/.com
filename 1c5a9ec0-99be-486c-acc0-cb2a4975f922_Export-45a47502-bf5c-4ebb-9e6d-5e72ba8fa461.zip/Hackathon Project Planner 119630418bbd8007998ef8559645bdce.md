# Hackathon Project Planner

<aside>
💡 **Notion Tip:** Use this template to facilitate efficient collaboration and project management among your team. Share this page with each member of your team.

</aside>

[Team](Hackathon%20Project%20Planner%20119630418bbd8007998ef8559645bdce/Team%20119630418bbd81af9861e00c778fa051.csv)

# Planning

---

[1. Exploring the Problem](Hackathon%20Project%20Planner%20119630418bbd8007998ef8559645bdce/1%20Exploring%20the%20Problem%20119630418bbd812dad81dccc7c5f29b7.md)

[2. Ideation](Hackathon%20Project%20Planner%20119630418bbd8007998ef8559645bdce/2%20Ideation%20119630418bbd81679d64c1bba332e443.md)

[3. Planning and Organization](Hackathon%20Project%20Planner%20119630418bbd8007998ef8559645bdce/3%20Planning%20and%20Organization%20119630418bbd8117a69cdb54843a5981.md)

[4. Development](Hackathon%20Project%20Planner%20119630418bbd8007998ef8559645bdce/4%20Development%20119630418bbd8183939dec24774e15c6.md)

[5. Testing and Refinement](Hackathon%20Project%20Planner%20119630418bbd8007998ef8559645bdce/5%20Testing%20and%20Refinement%20119630418bbd81e2b4d2cb4b5a5074f7.md)

[6. Preparation for Presentation](Hackathon%20Project%20Planner%20119630418bbd8007998ef8559645bdce/6%20Preparation%20for%20Presentation%20119630418bbd8124b4eccb0c1f5d0ceb.md)

[7. Final Presentation](Hackathon%20Project%20Planner%20119630418bbd8007998ef8559645bdce/7%20Final%20Presentation%20119630418bbd819997f5f4a94dc265a8.md)

[8. Post-Hackathon](Hackathon%20Project%20Planner%20119630418bbd8007998ef8559645bdce/8%20Post-Hackathon%20119630418bbd81d88864e14bf4be27df.md)

# Tasks

---

[Tasks](Hackathon%20Project%20Planner%20119630418bbd8007998ef8559645bdce/Tasks%20119630418bbd815ba526c7c202ef46be.csv)

# GitHub Repo

↓ Connect your GitHub to sync your project repository into a Notion database.

[Sin título](Hackathon%20Project%20Planner%20119630418bbd8007998ef8559645bdce/Sin%20ti%CC%81tulo%20119630418bbd81f183f7e55e5531c3a9.csv)