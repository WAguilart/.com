# Technology Stack Selection

Assign: Florence Rossi, Amaya Hernandez
Status: Not started