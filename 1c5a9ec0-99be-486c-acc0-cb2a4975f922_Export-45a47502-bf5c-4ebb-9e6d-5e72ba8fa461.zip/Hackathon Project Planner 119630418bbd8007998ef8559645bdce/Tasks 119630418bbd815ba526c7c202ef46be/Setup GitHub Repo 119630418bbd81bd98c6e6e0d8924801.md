# Setup GitHub Repo

Assign: Florence Rossi
Status: In progress