# 1. Exploring the Problem

<aside>
💡 **Notion Tip:** Kickstart your project by responding to the prompts in the toggles below. Add more context to your answer by embedding links, images, files, and other blocks.

</aside>

- **Understand the Theme**: Start by deeply understanding the theme and specific challenges of the hackathon. Research any relevant industries, technologies, and user demographics.
- **Identify Pain Points**: Discuss with teammates or mentors to identify key pain points that need addressing. Use surveys, interviews, or secondary research to gather more insights.
- **Problem Statement**: Refine your understanding into a clear and concise problem statement that your project will address.