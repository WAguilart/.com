# Resource Gathering

Assign: Florence Rossi
Status: Not started